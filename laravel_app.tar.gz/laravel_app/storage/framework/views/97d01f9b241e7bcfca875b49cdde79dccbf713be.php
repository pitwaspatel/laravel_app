<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<p class="text-right">
    <a href="<?php echo e(route('student')); ?>">Back</a>
</p>
<div class="container">
    <table class="table table-bordered data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Student Name</th>
                <th>Roll No.</th>
                <th>Class</th>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($subject->subject_name); ?>


                </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

                <th>Marks Obtained</th>
               <!--<th>Total Marks</th>-->
               <!--<th width="100px">Action</th>-->
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>


<script type="text/javascript">
$(function () {

    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('student-list')); ?>",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'},
            {data: 'student_name'},
            {data: 'roll_no', name: 'roll_no'},
            {data: 'class', name: 'class'},
            {data: '3', name: '3'},
            {data: '5', name: '5'},
            {data: '2', name: '2'},
            {data: '1', name: '1'},
            {data: '6', name: '6'},
            {data: '4', name: '4'},
//            {data: 'subject.total_marks', name: 'subject.total_marks'},
            {data: 'total_marks', name: 'total_marks'},
//            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });

});
</script>
<?php /**PATH /var/www/html/blog/resources/views/users.blade.php ENDPATH**/ ?>