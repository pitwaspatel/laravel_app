<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentMearkSheetData extends Model {

    protected $table = 'student_marksheet_data';
    protected $primaryKey = 'id';
    protected $fillable = [
        'student_id', 'subject_id', 'marks_obtained'
    ];

    public function student() {
        return $this->hasOne(Student::class, 'id');
    }

    public function subject() {
        return $this->hasOne(MasterSubject::class, 'id');
    }

}
