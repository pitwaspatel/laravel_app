<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model {

    protected $table = 'student';
    protected $primaryKey = 'id';
    protected $fillable = [
        'student_name', 'roll_no', 'student_photo', 'class_id'
    ];
        public function class() {
        return $this->hasOne(MasterClass::class, 'id','class_id');
    }

}
