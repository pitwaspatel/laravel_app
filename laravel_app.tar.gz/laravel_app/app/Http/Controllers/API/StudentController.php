<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\API\BaseController as BaseController;
use App\Student;
use App\StudentMearkSheetData;
use Validator;
use App\Http\Resources\Student as StudentResource;

class StudentController extends BaseController {

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        $data = StudentMearkSheetData::with('student', 'subject')->orderBy('marks_obtained')->get()->toArray();
        $arr = [];
        $student = Student::with('class')->get()->toArray();

        $total_marks = [];
        foreach ($data as $k => $value) {
            $arr[$value['student_id']][$value['subject_id']] = $value['marks_obtained'];
            foreach ($student as $s) {
                if ($value['student_id'] == $s['id']) {
                    $total_marks[] += $value['marks_obtained'];
                    $arr[$value['student_id']]['student_name'] = $s['student_name'];
                    $arr[$value['student_id']]['roll_no'] = $s['roll_no'];
                    $arr[$value['student_id']]['class'] = $s['class']['class_name'];
                    $arr[$value['student_id']]['photo'] = $s['student_photo'];
                    $arr[$value['student_id']]['total_marks'] = array_sum(array_slice($total_marks, -6, 6, true));
                }
            }
        }
        return $this->sendResponse(StudentResource::collection($arr), 'Data retrieved successfully.');
    }

}
