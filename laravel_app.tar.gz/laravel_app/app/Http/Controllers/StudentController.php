<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\MasterClass;
use App\MasterSubject;
use App\StudentMearkSheetData;
use App\Student;
use Yajra\DataTables\DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller {

    public function index() {

        $classes = MasterClass::all()->sortBy('id');
        $subjects = MasterSubject::all()->sortBy('subject_name');
        return view('student', compact('classes', 'subjects'));
    }

    protected static function create(Request $req) {

        $req->validate([
            'student_photo' => 'required|mimes:png|max:2048',
            'roll_no' => 'required|unique:student',
            'student_name' => 'required',
            'class_id' => 'required',
            "marks_obtained.*" => "required|numeric|max:100",
        ]);

        $fileName = time() . '.' . $req->student_photo->getClientOriginalName();
        $req->student_photo->move(public_path('uploads'), $fileName);
        DB::beginTransaction();
        try {

            $model = new Student();
            $model->student_name = $req['student_name'];
            $model->roll_no = $req['roll_no'];
            $model->class_id = $req['class_id'];
            $model->created_by = Auth::user()->id;
            $model->student_photo = $fileName;
            $model->save();

            $data = [];
            foreach ($req->marks_obtained as $k => $val) {
                $data[] = [
                    'student_id' => $model->id,
                    'subject_id' => $k,
                    'marks_obtained' => $val,
                ];
            }
            StudentMearkSheetData::insert($data);
            DB::commit();
             return \Illuminate\Support\Facades\Redirect::to('/student-list');

        } catch (Exception $exc) {
            DB::rollback();

            echo $exc->getTraceAsString();
        }
    }

    protected function list(Request $req) {
        $subjects = MasterSubject::all()->sortBy('subject_name');

        if ($req->ajax()) {
            $data = StudentMearkSheetData::with('student', 'subject')->orderBy('student_id','desc')->get()->toArray();
            $arr = [];
            $student = Student::with('class')->get()->toArray();

            $total_marks = [];
            foreach ($data as $k => $value) {
                $arr[$value['student_id']][$value['subject_id']] = $value['marks_obtained'];
                foreach ($student as $s) {
                    if ($value['student_id'] == $s['id']) {
                        $total_marks[] += $value['marks_obtained'];
                        $arr[$value['student_id']]['student_name'] = $s['student_name'];
                        $arr[$value['student_id']]['roll_no'] = $s['roll_no'];
                        $arr[$value['student_id']]['class'] = $s['class']['class_name'];
                        $arr[$value['student_id']]['total_marks'] = array_sum(array_slice($total_marks, -6, 6, true));
                    }
                }
            } return Datatables::of($arr)
                            ->addIndexColumn()
                            ->make(true);
        }

        return view('users', compact('subjects'));
    }

}
