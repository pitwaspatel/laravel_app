<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterClass extends Model {

    protected $table = 'master_class';
    protected $primaryKey = 'id';
    protected $fillable = [
        'class_name'
    ];

}
