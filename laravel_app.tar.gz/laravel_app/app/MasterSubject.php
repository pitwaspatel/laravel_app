<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterSubject extends Model {

    protected $table = 'master_subject';
    protected $primaryKey = 'id';
    protected $fillable = [
        'subject_name','total_marks'
    ];

}
