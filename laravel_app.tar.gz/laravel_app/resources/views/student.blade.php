@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Student MarkSheet Data') }}</div>

                <div class="card-body">
                    <form method="POST"  action="{{ route('student-create') }}" enctype="multipart/form-data">
                        @csrf

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Student Name') }}</label>

                            <div class="col-md-6">
                                <input id="student_name" type="text" class="form-control @error('student_name') is-invalid @enderror" name="student_name" value="{{ old('student_name') }}"  autocomplete="student_name" autofocus>

                                @error('student_name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="roll_no" class="col-md-4 col-form-label text-md-right">{{ __('Roll No') }}</label>

                            <div class="col-md-6">
                                <input id="roll_no" type="text" class="form-control @error('roll_no') is-invalid @enderror" name="roll_no" value="{{ old('roll_no') }}"  autocomplete="email">

                                @error('roll_no')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="student_photo" class="col-md-4 col-form-label text-md-right">{{ __('Photo') }}</label>

                            <div class="col-md-6">
                                <input id="student_photo" type="file" class="form-control @error('student_photo') is-invalid @enderror" name="student_photo"  autocomplete="student_photo">

                                @error('student_photo')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">




                            <label for="class_id" class="col-md-4 col-form-label text-md-right">{{ __('Class') }}</label>

                            <div class="col-md-6">
                                @error('class_id')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                                <select id="class_id"  name="class_id" class="form-control @error('student_photo') is-invalid @enderror">
                                    <option  value="">--Select Class--</option>
                                    @foreach($classes as $class)
                                    <option value="{{ $class->id }}"}}>{{ $class->class_name }}</option>    
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-12">
                                <table class="table table-responsive">
                                    <tr>
                                        <td>Subject Name</td>
                                        <td>Mark Obtains</td>
                                        <td>Total Marks</td>
                                    </tr>
                                    @foreach($subjects as $subject)
                                    <tr>
                                        <td> <option value="{{ $subject->id }}"}}>{{ $subject->subject_name }}</option>  </td>
                                    <td><input id="marks_obtained[{{$subject->id}}]" type="text" class="form-control @error('marks_obtained.*') is-invalid @enderror" name="marks_obtained[{{$subject->id}}]" autocomplete="marks_obtained">
                                        @error('marks_obtained.*')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </td>
                                    <td class="text-right">{{$subject->total_marks}}</td>
                                    </tr>
                                    @endforeach  


                                </table>
                            </div>
                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Save') }}
                                </button>
                                <button type="reset" class="btn btn-danger">
                                    {{ __('Reset') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
